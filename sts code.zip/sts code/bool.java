
public class bool {

}
